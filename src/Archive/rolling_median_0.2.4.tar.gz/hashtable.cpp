#include <iostream>
#include <string>
#include "graph.h"
#include "stringutils.h"


// FNV-1a hash algorithm for short strings from
// http://www.isthe.com/chongo/tech/comp/fnv/
hashtype calc_hash(std::string str) {

// I will use 32 bit version, as the array will be smaller than that
#define FNV_OFFSET32 2166136261
#define FNV_OFFSET64 14695981039346656037
#define FNV_PRIME32 16777619
#define FNV_PRIME64 1099511628211

  hashtype hash = FNV_OFFSET32;
  for(std::string::iterator it = str.begin(); it != str.end(); ++it) {
    hash ^= *it;
    hash *= FNV_PRIME32;
  }
  return hash;
}

namespace hashtable {
  // size of node hash table
  const hashtype hashmask1 = 0xFFFF;
  // size of edge hash table for each of 60 seconds = nodesize/8
  const hashtype hashmask2 = (hashmask1 >> 3);

  hashtype mkhash1(std::string str) {
    return ( calc_hash(str) ) & hashmask1;
  }

  hashtype mkhash2(std::string str1, std::string str2) {
    // Concatenate actor name and target name.
    // With actor and target previously lexicographically ordered,
    // this is symmetrized for non-directional edges.
    return ( calc_hash(str1 + str2) ) & hashmask2;
  }
}

inline Content* List::getContent() const {
  return content;
}

inline List* List::getPrev() const {
  return prev;
}

inline List* List::getNext() const {
  return next;
}

inline void Hashtable::putContent(Content* content, hashtype hash) {
  table[hash] = content;
}

inline Content* Hashtable::getContent(hashtype hash) const {
  return table[hash];
}

Hashtable::~Hashtable() {
  free(table);
}
