#include <iostream>     // std::cout
#include "venmodata.h"
#include "hashtable.h"
#include "graph.h"

inline std::string Node::getStr() const {
  return str;
}

inline uint Node::getDeg() const {
  return deg;
}

inline void Node::incDeg() {
  ++deg;
}

inline void Node::decDeg() {
  --deg;
}

inline Node* Edge::getNode(int index) const {
  return nodes[index];
}

void Graph::process(venmodata* vdt) {
  // create objects and update data structures
  time_t timediff = vdt->epochtime - currtime;
  if( timediff <= -60 ) {
    // new data is too old to insert, ignore
    return;
  } else {
    if( timediff > 0) {
      // new data estabishes new, more recent, current time
      // ??? evict existing data that has aged out
      // make new time current time
      currtime = vdt->epochtime;
      currsec = vdt->sec;
    }
    hashtype ehash = htb::mkhash2(vdt->actor, vdt->target);
    Node* mynode[EN] = {new Node(vdt->actor), new Node(vdt->target)};
    Edge* myedge = new Edge(mynode[0], mynode[1]);
    insertEdge(myedge, vdt->sec, ehash);

    // test output
    std::cout << "inserted with hash: " << ehash << std::endl;
    Hashtable* myetab =
      dynamic_cast<Hashtable*>(etab->getContent(vdt->sec));
    List* mylist = dynamic_cast<List*>(myetab->getContent(ehash));
    Edge* mymyedge = dynamic_cast<Edge*>(mylist->getContent());
    for(int ii = 0; ii < EN; ii++) {
      std::cout << "name" << ii << ": " << mymyedge->getNode(ii)->getStr() << std::endl;
      std::cout << "deg" << ii << ": " << mymyedge->getNode(ii)->getDeg() << std::endl;
    }
  }
}

Graph::~Graph() {
  // must be executed in this order, as etab deletes elements in ntab
  delete etab;
  delete ntab;
}

void Graph::insertEdge(Edge* myedge, uint sec, hashtype ehash) {
  // Get current second's edge hash table
  Hashtable* myetab = dynamic_cast<Hashtable*>(etab->getContent(sec));

  // Create if no hashtable exists at this second
  if( NULL == myetab ) {
    myetab = new Hashtable(htb::hashmask2);
    // We know there are no entry in this new table,
    // so go ahead and create everything
    myetab->putContent(new List(myedge), ehash);
    etab->putContent(myetab, sec);
  } else {
    List* myelist = dynamic_cast<List*>(myetab->getContent(ehash));
    if( NULL == myelist ) {
      // ???
    } else {
      // ???
    }
  }
}
