#include <sstream>
#include <iostream>
#include <string>
#include <locale>
#include "venmodata.h"
#include "venmoio.h"
#include "epochtime.h"
#include "stringutils.h"
#include "graph.h"


int main(int argc, char* argv[]) {

  // Expect two command line parameters, input and output filenames
  if(argc != 3) {
    stu::abortf("usage: %s <inputfile> <outputfile>\n", argv[0]);
  }

  // bash command line is limited size and we are using run script,
  // so command line parameters not sanitized
  // opens files and creates output directory of needed
  venmoio vio(argv[1], argv[2]);

  // object that holds json data and flag showing which elements were
  // supplied, see venmodata.h
  venmodata vdt("", "", "", 0);

  // vio.parseLine() reads a line and fills elements of vdt
  while( vio.parseLine(&vdt) ) {
    if( vdt.FlagAll == vdt.supplied ) {
      vdt.cout();

      // edges are non-directional, so swap if needed to obtain
      // lexicographically ordered actor <= target
      if( vdt.actor > vdt.target ) {
        std::string tempstr = vdt.actor;
        vdt.actor = vdt.target;
        vdt.target = tempstr;
      }

      vdt.cout();

      node mynode1(vdt.actor);
      node mynode2(vdt.target);
      std::cout << "node1 str = " << (mynode1.getstr()) << std::endl;
      std::cout << "node2 str = " << (mynode2.getstr()) << std::endl;
      std::cout << "node1 hash = " << (mynode1.gethash()) << std::endl;
      std::cout << "node2 hash = " << (mynode2.gethash()) << std::endl;
      std::cout << "node1 deg = " << (mynode1.deg) << std::endl;
      std::cout << "node2 deg = " << (mynode2.deg) << std::endl;
    }
  }

  return 0;
}
