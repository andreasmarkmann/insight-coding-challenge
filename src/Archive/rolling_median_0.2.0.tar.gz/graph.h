#ifndef GRAPH_H
#define GRAPH_H
#include <cstddef>
#include <string>

typedef unsigned int thash;

// abstract element type, computes and holds its own hash
class elem {
protected:
  thash hash;

public:
  elem(thash hash = 0): hash(hash) {};
  // pure virtual hash function
  virtual thash gethash() const;
  virtual void mkhash() = 0;
};

// abstract linked list type for holding elements
// allowing hash collision aka bucket
class elemlist : public elem {
protected:
  elem* content;
  elemlist* next;
public:
  elem* getContent();
  elemlist(elem* content = NULL, elemlist* next = NULL):
    content(content), next(next) {};
};

// node element holding string str for a person's name and node degree
class node : public elem {
protected:
  std::string str;
public:
  int deg;
  std::string getstr() const;
  virtual void mkhash();
  // initialize new node with degree 1 or 0???
  node(std::string str): str(str), deg(1) { this->mkhash(); };
  node(std::string str, thash hash): elem(hash), str(str), deg(1) {};
};

// linked list for holding edges
// allowing hash collision aka bucket
class edgelist : public elemlist {
protected:
  elemlist* actor;
  elemlist* target;
public:
  virtual void mkhash();
  edgelist(elemlist* actor, elemlist* target);
};

// I want to recursively store hash tables in hash tables,
// so define hash table as derived from elem
class hashtable : public elem {
protected:
  std::size_t size;

public:
  elem** table;

  // initializer list instead of constructor
  hashtable(size_t size, thash hash = 0):
    size(size), elem(hash) {
    this->table = (elem**)malloc(this->size * sizeof(elem*));
  };
  ~hashtable();
};

class edgetable : public hashtable {
protected:

public:
};



#endif
