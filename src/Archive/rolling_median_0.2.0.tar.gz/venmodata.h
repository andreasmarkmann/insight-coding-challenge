#ifndef VENMODATA_H
#define VENMODATA_H
#include <string>
#include <fstream>

class venmodata {
public:
  std::string actor, target, time;
  std::string** Contents;
  int supplied;

  // Number of supported Json tags
  static const int NNames;
  // Logical flags for which tags have been supplied
  static const int Flags[], FlagNone;
  static int FlagAll;
  // Strings containing supported Json tags
  static const char* Names[];

  // initializer list & constructor
  venmodata(std::string actor, std::string target,
            std::string time, int supplied):
            actor(actor), target(target), time(time), supplied(supplied) {
              // initialize FlagAll to contain all Flags
              for(int ii = 0; ii < this->NNames; ii++) {
                this->FlagAll |= this->Flags[ii];
              }
              this->Contents = (std::string**)malloc(
                this->NNames * sizeof(std::string*) );
              // Points Contents array at object members
              // same order as Names, Flags
              // to avoid switching for named object members
              this->Contents[0] = &(this->time);
              this->Contents[1] = &(this->actor);
              this->Contents[2] = &(this->target);
            };
  ~venmodata();
  void cout();
};

#endif
