#ifndef GRAPH_H
#define GRAPH_H
#include <cstddef>
#include <string>

typedef unsigned int hashtype;

// abstract element type, computes and holds its own hash
class elem {
protected:
  hashtype hash;

public:
  elem(hashtype hash = 0): hash(hash) {};
  // pure virtual hash function
  virtual hashtype gethash() const;
  virtual void mkhash() = 0;
};

// node element holding string str for a person's name and node degree
class node : public elem {
protected:
  std::string str;
public:
  int deg;

  // Initialize new node with degree 1 or 0???
  node(std::string str): str(str), deg(1) { this->mkhash(); };
  node(std::string str, hashtype hash):
    elem(hash), str(str), deg(1) {};
  virtual void mkhash();
  virtual std::string getstr() const;
};

// edge element holding string str for a person's name and node degree
class edge : public elem {
protected:
  node* actor;
  node* target;
public:
  edge(node* actor, node* target):
    actor(actor), target(target) { this->mkhash(); };
  edge(node* actor, node* target, hashtype hash):
    elem(hash), actor(actor), target(target) {};
  virtual void mkhash();
  virtual node* getactor() const;
  virtual node* gettarget() const;
};

// abstract linked list type for holding any type of element
// allowing hash collision aka bucket
class elemlist : public elem {
protected:
  elem* content;
  elemlist* prev;
  elemlist* next;
public:
  elemlist(elem* content, elemlist* prev = NULL, elemlist* next = NULL): content(content), prev(prev), next(next) { this->mkhash(); };
  virtual elem* getContent();
  virtual elemlist* getprev();
  virtual elemlist* getnext();
  virtual void mkhash();
};

// hash table class derived from elem (with hash), so we can have
// hash tables containing hash tables
class hashtable : public elem {
protected:
  std::size_t size;

public:
  elem** table;

  // initializer list instead of constructor
  hashtable(size_t size, hashtype hash = 0):
    size(size), elem(hash) {
    this->table = (elem**)malloc(this->size * sizeof(elem*));
  };
  ~hashtable();
  virtual void mkhash();
};

// class edgetable : public hashtable {
// protected:
//
// public:
// };



#endif
