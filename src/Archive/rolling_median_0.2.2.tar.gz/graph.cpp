#include <iostream>
#include <string>
#include "graph.h"
#include "stringutils.h"

// size of node hash table
#define NODESIZE 65536

// size of edge hash table for each of 60 seconds = nodesize/8
#define EDGESIZE (NODESIZE >> 3)


// FNV-1a hash algorithm for short strings from
// http://www.isthe.com/chongo/tech/comp/fnv/
hashtype calc_hash(std::string str) {

// I will use 32 bit version, as the array will be smaller than that
#define FNV_OFFSET32 2166136261
#define FNV_OFFSET64 14695981039346656037
#define FNV_PRIME32 16777619
#define FNV_PRIME64 1099511628211

  hashtype hash = FNV_OFFSET32;
  for(std::string::iterator it = str.begin(); it != str.end(); ++it) {
    hash ^= *it;
    hash *= FNV_PRIME32;
  }
  return hash;
}

inline hashtype elem::gethash() const {
  return this->hash;
}

inline std::string node::getstr() const {
  return this->str;
}

void node::mkhash() {
  this->hash = ( calc_hash(this->str) ) % NODESIZE;
}

void edge::mkhash() {
  // Concatenate actor name and target name.
  // With actor and target previously lexicographically ordered,
  // this is symmetrized for non-directional edges.
  this->hash =
    ( calc_hash(this->actor->getstr()
      + this->target->getstr()) ) % EDGESIZE;
}

inline node* edge::getactor() const {
  return this->actor;
}

inline node* edge::gettarget() const {
  return this->target;
}

inline elem* elemlist::getContent() {
  return this->content;
}

inline elemlist* elemlist::getprev() {
  return this->prev;
}

inline elemlist* elemlist::getnext() {
  return this->next;
}

void elemlist::mkhash() {
  this->hash = this->content->gethash();
}

hashtable::~hashtable() {
  free(table);
}

// hashes for tables are initialized and never computed
void hashtable::mkhash() {
  stu::abortf("Called mkhash() for hash table, this should not happen.\n");
}
