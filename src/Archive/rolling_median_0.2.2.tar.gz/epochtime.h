#ifndef EPOCHTIME_H
#define EPOCHTIME_H

#define EPOCHTIME_FAIL 1
#define EPOCHTIME_SUCCESS 0

#define UTCTIMELEN 20

namespace epochtime {
  time_t epochParse(const char *UTCstring);
  void epochParseTest(const char *UTCstring);
}

// provide standardized shorthand namespace to save typing
namespace ept = epochtime;

#endif
