#include <sstream>
#include <iostream>
#include <string>
#include <locale>
#include "venmodata.h"
#include "venmoio.h"
#include "epochtime.h"
#include "stringutils.h"
#include "graph.h"


int main(int argc, char* argv[]) {

  // Expect two command line parameters, input and output filenames
  if(argc != 3) {
    stu::abortf("usage: %s <inputfile> <outputfile>\n", argv[0]);
  }

  // bash command line is limited size and we are using run script,
  // so command line parameters not sanitized
  // opens files and creates output directory of needed
  venmoio vio(argv[1], argv[2]);

  // object that holds json data and flag showing which elements were
  // supplied, see venmodata.h
  venmodata vdt("", "", "", 0);

  // vio.parseLine() reads a line and fills elements of vdt
  while( vio.parseLine(&vdt) ) {
    if( vdt.FlagAll == vdt.supplied ) {
      vdt.cout();

      // edges are non-directional, so swap if needed to obtain
      // lexicographically ordered actor <= target
      if( vdt.actor > vdt.target ) {
        std::string tempstr = vdt.actor;
        vdt.actor = vdt.target;
        vdt.target = tempstr;
      }

      vdt.cout();

      // create objects for insertion into data structures
      node* mynode1 = new node(vdt.actor);
      node* mynode2 = new node(vdt.target);
      std::cout << "node1 str = " << (mynode1->getstr()) << std::endl;
      std::cout << "node2 str = " << (mynode2->getstr()) << std::endl;
      std::cout << "node1 hash = " << (mynode1->gethash()) << std::endl;
      std::cout << "node2 hash = " << (mynode2->gethash()) << std::endl;
      std::cout << "node1 deg = " << (mynode1->deg) << std::endl;
      std::cout << "node2 deg = " << (mynode2->deg) << std::endl;

      edge* myedge = new edge(mynode1, mynode2);
      std::cout << "edge a = " << (myedge->getactor()->getstr()) << std::endl;
      std::cout << "edge t = " << (myedge->gettarget()->getstr()) << std::endl;
      std::cout << "edge a hash = " << (myedge->getactor()->gethash()) << std::endl;
      std::cout << "edge t hash = " << (myedge->gettarget()->gethash()) << std::endl;
      std::cout << "edge a hash = " << (myedge->getactor()->deg) << std::endl;
      std::cout << "edge t hash = " << (myedge->gettarget()->deg) << std::endl;

      elemlist* mynodelist1 = new elemlist(mynode1);
      std::cout << "nodelist1 str = "
      << (dynamic_cast<node*>(mynodelist1->getContent())->getstr()) << std::endl;
      std::cout << "nodelist1 hash = " << mynodelist1->gethash() << std::endl;
      std::cout << "nodelist1 prev, next = " << mynodelist1->getprev() << " " << mynodelist1->getnext() << std::endl;

    }
  }

  return 0;
}
