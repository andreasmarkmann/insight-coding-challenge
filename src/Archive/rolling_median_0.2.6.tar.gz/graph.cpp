#include <iostream>     // std::cout
#include "stringutils.h"
#include "venmodata.h"
#include "hashtable.h"
#include "graph.h"

inline std::string Node::getStr() const {
  return str;
}

inline uint Node::getDeg() const {
  return deg;
}

inline void Node::incDeg() {
  ++deg;
}

inline void Node::decDeg() {
  --deg;
}

inline Node* Edge::getNode(int index) const {
  return nodes[index];
}

inline void Edge::putNode(Node* node, int index) {
  nodes[index] = node;
}

void Graph::process(venmodata* vdt) {
  // create objects and update data structures
  time_t timediff = vdt->epochtime - currtime;
  if( timediff <= -60 ) {
    // new data is too old to insert, ignore
    return;
  } else {
    if( timediff > 0) {
      // new data estabishes new, more recent, current time
      // ??? evict existing data that has aged out
      // make new time current time
      currtime = vdt->epochtime;
      currsec = vdt->sec;
    }
    hashtype ehash = htb::mkhash2(vdt->actor, vdt->target);
    Node* mynode[EN] = {new Node(vdt->actor), new Node(vdt->target)};
    Edge* myedge = new Edge(mynode[0], mynode[1]);
    insertEdge(myedge, vdt->sec, ehash);

    // test output
    std::cout << "inserted with hash: " << ehash << std::endl;
    Hashtable* myetab =
      dynamic_cast<Hashtable*>(etab->getContent(vdt->sec));
    List* mylist = dynamic_cast<List*>(myetab->getContent(ehash));
    Edge* mymyedge = dynamic_cast<Edge*>(mylist->getContent());
    for(int ii = 0; ii < EN; ii++) {
      std::cout << "name" << ii << ": " << mymyedge->getNode(ii)->getStr() << std::endl;
      std::cout << "deg" << ii << ": " << mymyedge->getNode(ii)->getDeg() << std::endl;
    }
  }
}

Graph::~Graph() {
  // must be executed in this order, as etab deletes elements in ntab
  delete etab;
  delete ntab;
}

void Graph::insertEdge(Edge* myedge, uint sec, hashtype ehash) {
  // Get current second's edge hash table
  Hashtable* sectab = dynamic_cast<Hashtable*>(etab->getContent(sec));

  // ??? check if this hash/names exist at ANY PREVIOUS second

  // Create if no hashtable exists at this second
  if( NULL == sectab ) {
    // No data at this second
    edgenum++;
    sectab = new Hashtable(htb::hashmask2);
    // We know there are no entries in this new table,
    // so go ahead and create everything
    sectab->putContent(new List(myedge), ehash);
    etab->putContent(sectab, sec);
    for(int ii = 0; ii < EN; ii++) {
      insertNode( myedge->getNode(ii),
                  htb::mkhash1( myedge->getNode(ii)->getStr() ) );
    }
  } else {
    List* myelist = dynamic_cast<List*>(sectab->getContent(ehash));
    if( NULL == myelist ) {
      // Empty hash at this second
      edgenum++;
      for(int ii = 0; ii < EN; ii++) {
        Node* newnode = insertNode( myedge->getNode(ii),
          htb::mkhash1( myedge->getNode(ii)->getStr() ) );
        // Matched node is returned if name matches
        if( myedge->getNode(ii) != newnode ) {
          myedge->putNode(newnode, ii);
        }
      }
      sectab->putContent(new List(myedge), ehash);
    } else {
      // ???
    }
  }
}

Node* Graph::insertNode(Node* mynode, hashtype nhash) {

  List* mynlist = dynamic_cast<List*>(ntab->getContent(nhash));
  // If there are few hash collisions, this is often NULL
  if( NULL == mynlist ) {
    ntab->putContent(new List(mynode), nhash);
    degrees[mynode->getDeg()]++;
  } else {
    // Hash collision, other nodes with same hash exist
    // Search through doubly linked, lexicographically sorted list
    // Define "before" list item
    List* befnlist = NULL;
    while( NULL != mynlist && mynode->getStr() >
      dynamic_cast<Node*>(mynlist->getContent())->getStr() ) {
      befnlist = mynlist;
      mynlist = mynlist->getNext();
    }
    // Check if we are at end of list
    if( NULL == mynlist ) {
      // insert at end
      if( NULL == befnlist ) {
        stu::abortf("Trying to insert node %s at hash %i after NULL pointer\n", mynode->getStr(), nhash);
      } else {
        befnlist->putNext(new List(mynode));
        befnlist->getNext()->putPrev(befnlist);
        degrees[mynode->getDeg()]++;
      }
    } else {
      // check if we have a match
      if( mynode->getStr()
      == dynamic_cast<Node*>(mynlist->getContent())->getStr() ) {
        // increment degree of existing node and delete mynode
        delete mynode;
        mynode = dynamic_cast<Node*>(mynlist->getContent());
        degrees[mynode->getDeg()]--;
        mynode->incDeg();
        degrees[mynode->getDeg()]++;
      } else {
        // Insert mynode list item in between existing items
        // befnlist and mynlist, we know mynlist != NULL
        List* newnlist = new List(mynode);
        mynlist->putPrev(newnlist);
        newnlist->putNext(mynlist);
        if( NULL == befnlist ) {
          // register newnlist as first list element with hash table
          ntab->putContent(newnlist, nhash);
        } else {
          // connect up with existing "before" list item
          befnlist->putNext(newnlist);
          newnlist->putPrev(befnlist);
        }
        degrees[mynode->getDeg()]++;
      }
    }
  }

  if( NULL == mynode ) {
    stu::abortf("mynode was NULL in insertNode\n");
  }
  if( mynode->getDeg() > maxdeg ) {
    maxdeg = mynode->getDeg();
  }
  return mynode;
}

void Graph::output() {
  uint sum = 0;
  std::cout << "degree occupations: ";
  for(int ii = 0; ii <= maxdeg; ii++) {
    sum += ii*degrees[ii];
    std::cout << degrees[ii] << " ";
  }
  std::cout << std::endl;
  std::cout << "sum, 2*edgenum = " << sum << " " << (2*edgenum) << std::endl;
}
