#include <iostream>
#include <string>
#include "venmodata.h"

const int venmodata::NNames = 3;

const int venmodata::Flags[]  = {0x01, 0x02, 0x04};
const int venmodata::FlagAll  = 0x07;
const int venmodata::FlagNone = 0x00;

const char* venmodata::Names[] = {"actor", "target", "created_time"};

void venmodata::cout() {
    // evaluate data parsed into new object
    std::cout << this->venmodata::Names[0] << ": \"" << this->actor
    << "\" " << this->venmodata::Names[1] << ": \"" << this->target
    << "\" " << this->venmodata::Names[2] << ": \"" << this->time
    << "\" " << "Supplies" << ": \"" << this->supplied
    << "\"" << std::endl;
}
