#include <sstream>
#include <iostream>
#include <string>
#include <locale>
#include "venmodata.h"
#include "venmoio.h"
#include "epochtime.h"
#include "stringutils.h"


int main(int argc, char* argv[]) {

  // Expect two command line parameters, input and output filenames
  if(argc != 3) {
    stu::abortf("usage: %s <inputfile> <outputfile>\n", argv[0]);
  }

  // bash command line is limited size and we are using run script,
  // so command line parameters not sanitized
  // opens files and creates output directory of needed
  venmoio vio(argv[1], argv[2]);

  // object that holds json data and flag showing which elements were
  // supplied, see venmodata.h
  venmodata vdt("", "", "", 0);

  // vio.parseLine() reads a line and fills elements of vdt
  while( vio.parseLine(&vdt) ) {

    vdt.cout();
  }

  return 0;
}
