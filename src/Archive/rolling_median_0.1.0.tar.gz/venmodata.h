#ifndef VENMODATA_H
#define VENMODATA_H
#include <string>
#include <fstream>

class venmodata {
public:
  std::string actor, target, time;
  int supplied;

  // Number of supported Json tags
  static const int NNames;
  // Logical flags for which tags have been supplied
  static const int Flags[], FlagAll, FlagNone;
  // Strings containing supported Json tags
  static const char* Names[];

  // initializer list instead of constructor
  venmodata(std::string actor, std::string target,
            std::string time, int supplied):
            actor(actor), target(target), time(time), supplied(supplied) {};
  void cout();
};

#endif
