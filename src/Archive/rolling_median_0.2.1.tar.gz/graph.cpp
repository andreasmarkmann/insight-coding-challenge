#include <iostream>
#include <string>
#include "graph.h"

// size of node hash table
#define NODESIZE 65536

// size of edge hash table for each of 60 seconds = nodesize/8
#define EDGESIZE (NODESIZE >> 3)


// FNV-1a hash algorithm for short strings from
// http://www.isthe.com/chongo/tech/comp/fnv/
hashtype calc_hash(std::string str) {

// I will use 32 bit version, as the array will be smaller than that
#define FNV_OFFSET32 2166136261
#define FNV_OFFSET64 14695981039346656037
#define FNV_PRIME32 16777619
#define FNV_PRIME64 1099511628211

  hashtype hash = FNV_OFFSET32;
  for(std::string::iterator it = str.begin(); it != str.end(); ++it) {
    hash ^= *it;
    hash *= FNV_PRIME32;
  }
  return hash;
}

inline hashtype elem::gethash() const {
  return this->hash;
}

inline std::string node::getstr() const {
  return this->str;
}

void node::mkhash() {
  this->hash = (calc_hash(this->str)) % NODESIZE;
}

inline elem* elemlist::getContent() {
  return this-> content;
}

edgelist::edgelist(elemlist* actor, elemlist* target) {
  this->actor = actor;
  this->target = target;
}

void edgelist::mkhash() {
  // Concatenate actor name and target name.
  // With actor and target previously lexicographically ordered,
  // this is symmetrized for non-directional edges.
  node* actor = dynamic_cast<node*>(this->actor->getContent());
  node* target = dynamic_cast<node*>(this->target->getContent());
  if( actor && target ) {
    this->hash =
    (calc_hash(actor->getstr() + target->getstr()))
    % EDGESIZE;
  } else {
    hash = 0;
  }
}

hashtable::~hashtable() {
  free(table);
}

