#ifndef GRAPH_H
#define GRAPH_H
#include <cstddef>
#include <string>

typedef unsigned int hashtype;

// abstract class for content of linked lists
class Content  {
};

// node element holding string str for a person's name and node degree
class Node : public Content {
protected:
  std::string str;
public:
  // make degree of node public for easier access for now
  int deg;

  // Initialize new node with degree 1 or 0???
  Node(std::string str): str(str), deg(1) {};
  virtual std::string getStr() const;
};

// edge element holding two nodes
class Edge : public Content {
protected:
  Node* nodes[2];
public:
  Edge(Node* actor, Node* target)
    { nodes[0] = actor; nodes[1] = target; };
  virtual Node* getNode(int index) const;
};

namespace graph {
  hashtype mkhash1(std::string str);
  hashtype mkhash2(std::string str1, std::string str2);
}

// abstract linked list type for holding any type of element
// allowing hash collision aka bucket
class List {
protected:
  Content* content;
  List* prev;
  List* next;
public:
  List(Node* content, List* prev = NULL, List* next = NULL):
    content(content), prev(prev), next(next) {};
  virtual Content* getContent() const;
  virtual List* getPrev() const;
  virtual List* getNext() const;
};

// Class holding data with same hash value
class Hashed : public Content {
protected:
  hashtype hash;

public:
  Hashed(hashtype hash): hash(hash) {};
  // pure virtual hash function
  virtual hashtype getHash() const;
};

// Linked lists form buckets with hash collisions, so only hold hash
// for entire list
class Hashedlist : public Hashed {
protected:
  List* list;
public:
  Hashedlist(List* list, hashtype hash): list(list), Hashed(hash) {};
  virtual List* getList() const;
};

// hash table class derived from elem (with hash), so we can have
// hash tables containing hash tables
class Hashtable : public Hashed {
protected:
  std::size_t size;

public:
  Content** table;

  // initializer list instead of constructor
  Hashtable(size_t size, hashtype hash):
    size(size), Hashed(hash) {
    this->table = (Content**)malloc(this->size * sizeof(Content*));
  };
  ~Hashtable();
  virtual Content* putContent(Content* content, hashtype hash);
  virtual Content* getContent(hashtype hash) const;
};


#endif
