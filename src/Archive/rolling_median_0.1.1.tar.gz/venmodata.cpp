#include <iostream>
#include <string>
#include "venmodata.h"

const int venmodata::NNames = 3;

const int venmodata::Flags[]  = {0x01, 0x02, 0x04};
const int venmodata::FlagNone = 0x00;
// Contains all Flag bits, gets initialized in constructor
// with non-exclusive OR, so here's a preview of the result
int venmodata::FlagAll  = 0x07;

const char* venmodata::Names[] = {"created_time", "actor", "target"};

venmodata::~venmodata() {
  free(this->Contents);
}

void venmodata::cout() {
    // evaluate data parsed into new object
    std::cout
             << this->venmodata::Names[0] << ": \"" << this->time
    << "\" " << this->venmodata::Names[1] << ": \"" << this->actor
    << "\" " << this->venmodata::Names[2] << ": \"" << this->target
    << "\" " << "Supplies" << ": \"" << this->supplied
    << "\"" << std::endl;
}
