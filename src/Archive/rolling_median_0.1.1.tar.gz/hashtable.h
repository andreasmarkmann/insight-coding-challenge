#ifndef HASHTABLE_H
#define HASHTABLE_H
#include <string>
#include <fstream>

class hashtable {
public:
  unsigned long long int size;
  void** table;

  // pure virtual hash function
  virtual unsigned long long int hash(std::string str) const = 0;

  // initializer list instead of constructor
  hashtable(unsigned long long int size): size(size) {
    this->table = malloc();
  };
};

#endif
